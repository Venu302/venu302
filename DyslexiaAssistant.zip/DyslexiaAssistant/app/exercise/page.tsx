"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { motion } from 'framer-motion'

export default function Exercise() {
  const [userInput, setUserInput] = useState('')
  const [feedback, setFeedback] = useState('')

  const currentWord = "dyslexia" // This would normally come from an API or exercise generation logic

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (userInput.toLowerCase() === currentWord) {
      setFeedback("Correct! Great job!")
    } else {
      setFeedback(`Not quite. The correct word is "${currentWord}".`)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl mx-auto"
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Word Recognition Exercise</CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <p className="text-center text-2xl font-bold text-primary">{currentWord}</p>
            <Input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type the word you see above"
              className="text-center"
            />
            {feedback && (
              <p className={`text-center font-semibold ${feedback.startsWith('Correct') ? 'text-green-600' : 'text-red-600'}`}>
                {feedback}
              </p>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button type="submit">Submit</Button>
          </CardFooter>
        </form>
      </Card>
    </motion.div>
  )
}

