'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { analyzeDyslexiaPattern, generatePersonalizedExercises, textToSpeech, speechToText } from '@/lib/dyslexiaPatternRecognition'
import confetti from 'canvas-confetti'

export default function Training() {
  const [user, setUser] = useState<any>(null)
  const [currentExercise, setCurrentExercise] = useState<any>(null)
  const [userInput, setUserInput] = useState('')
  const [feedback, setFeedback] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [progress, setProgress] = useState(0)
  const router = useRouter()

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const userId = localStorage.getItem('userId')
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/user?userId=${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const userData = await response.json()
      if (response.ok) {
        setUser(userData)
        const pattern = await analyzeDyslexiaPattern(userData.screeningResults)
        const exercises = await generatePersonalizedExercises(pattern, userData.currentLevel)
        setCurrentExercise(exercises[0])
      } else {
        console.error(userData.error)
      }
    } catch (error) {
      console.error('An error occurred while fetching user data:', error)
    }
  }

  const handleSpeak = async () => {
    try {
      const audioContent = await textToSpeech(currentExercise.text)
      const audio = new Audio(`data:audio/mp3;base64,${audioContent}`)
      audio.play()
    } catch (error) {
      console.error('An error occurred during text-to-speech:', error)
    }
  }

  const handleListen = async () => {
    setIsListening(true)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      const audioChunks: BlobPart[] = []

      mediaRecorder.addEventListener('dataavailable', (event) => {
        audioChunks.push(event.data)
      })

      mediaRecorder.addEventListener('stop', async () => {
        const audioBlob = new Blob(audioChunks)
        const audioBuffer = await audioBlob.arrayBuffer()
        const result = await speechToText(Buffer.from(audioBuffer))
        setUserInput(result)
        setIsListening(false)
      })

      mediaRecorder.start()
      setTimeout(() => mediaRecorder.stop(), 5000) // Record for 5 seconds
    } catch (error) {
      console.error('An error occurred during speech recognition:', error)
      setIsListening(false)
    }
  }

  const handleSubmit = async () => {
    const correct = userInput.toLowerCase() === currentExercise.text.toLowerCase()
    setFeedback(correct ? 'Correct!' : `Incorrect. The correct answer was "${currentExercise.text}".`)

    if (correct) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      })
    }

    try {
      const userId = localStorage.getItem('userId')
      const token = localStorage.getItem('token')
      const response = await fetch('/api/user', {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          userId, 
          updates: { 
            [`progress.${user.currentLevel}`]: (user.progress?.[user.currentLevel] || 0) + 1 
          }
        }),
      })

      if (response.ok) {
        const updatedProgress = (user.progress?.[user.currentLevel] || 0) + 1
        setProgress(updatedProgress * 10)

        if (updatedProgress >= 10) {
          const levels = ['alphabet', 'word', 'phrase', 'sentence', 'paragraph']
          const currentIndex = levels.indexOf(user.currentLevel)
          if (currentIndex < levels.length - 1) {
            const nextLevel = levels[currentIndex + 1]
            await fetch('/api/user', {
              method: 'PUT',
              headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              },
              body: JSON.stringify({ 
                userId, 
                updates: { currentLevel: nextLevel }
              }),
            })
            router.push(`/training/${nextLevel}`)
          }
        } else {
          // Fetch next exercise
          const pattern = await analyzeDyslexiaPattern(user.screeningResults)
          const exercises = await generatePersonalizedExercises(pattern, user.currentLevel)
          setCurrentExercise(exercises[0])
        }
      }
    } catch (error) {
      console.error('An error occurred while updating progress:', error)
    }
  }

  if (!user || !currentExercise) return <div>Loading...</div>

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-100 to-blue-200 p-8">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="text-3xl capitalize">{user.currentLevel} Training</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-2xl font-bold mb-4">{currentExercise.text}</p>
          <div className="flex space-x-4 mb-4">
            <Button onClick={handleSpeak} className="w-1/2">
              Listen
            </Button>
            <Button onClick={handleListen} className="w-1/2" disabled={isListening}>
              {isListening ? 'Listening...' : 'Speak'}
            </Button>
          </div>
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="w-full p-2 text-xl border rounded"
            placeholder="Type your answer here..."
          />
          {feedback && (
            <p className={`mt-2 text-center text-xl ${feedback.startsWith('Correct') ? 'text-green-600' : 'text-red-600'}`}>
              {feedback}
            </p>
          )}
          <div className="mt-4">
            <div className="flex justify-between mb-1">
              <span>Progress</span>
              <span>{progress / 10}/10</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSubmit} className="w-full">Submit</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

