'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { analyzeDyslexiaPattern, generatePersonalizedExercises, textToSpeech, speechToText } from '@/lib/dyslexiaPatternRecognition'

export default function Training() {
  const [user, setUser] = useState<any>(null)
  const [currentExercise, setCurrentExercise] = useState<any>(null)
  const [userInput, setUserInput] = useState('')
  const [feedback, setFeedback] = useState('')
  const router = useRouter()

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const userId = localStorage.getItem('userId')
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/user?userId=${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const userData = await response.json()
      if (response.ok) {
        setUser(userData)
        const pattern = await analyzeDyslexiaPattern(userData.screeningResults)
        const exercises = await generatePersonalizedExercises(pattern, userData.currentLevel)
        setCurrentExercise(exercises[0])
      } else {
        console.error(userData.error)
      }
    } catch (error) {
      console.error('An error occurred while fetching user data:', error)
    }
  }

  const handleSpeak = async () => {
    try {
      const audioContent = await textToSpeech(currentExercise.text)
      const audio = new Audio(`data:audio/mp3;base64,${audioContent}`)
      audio.play()
    } catch (error) {
      console.error('An error occurred during text-to-speech:', error)
    }
  }

  const handleListen = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      const audioChunks: BlobPart[] = []

      mediaRecorder.addEventListener('dataavailable', (event) => {
        audioChunks.push(event.data)
      })

      mediaRecorder.addEventListener('stop', async () => {
        const audioBlob = new Blob(audioChunks)
        const audioBuffer = await audioBlob.arrayBuffer()
        const result = await speechToText(Buffer.from(audioBuffer))
        setUserInput(result)
      })

      mediaRecorder.start()
      setTimeout(() => mediaRecorder.stop(), 5000) // Record for 5 seconds
    } catch (error) {
      console.error('An error occurred during speech recognition:', error)
    }
  }

  const handleSubmit = async () => {
    const correct = userInput.toLowerCase() === currentExercise.text.toLowerCase()
    setFeedback(correct ? 'Correct!' : `Incorrect. The correct answer was "${currentExercise.text}".`)

    try {
      const userId = localStorage.getItem('userId')
      const token = localStorage.getItem('token')
      await fetch('/api/user', {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          userId, 
          updates: { 
            [`progress.${user.currentLevel}`]: (user.progress?.[user.currentLevel] || 0) + 1 
          }
        }),
      })

      // Move to next level if progress reaches threshold
      if ((user.progress?.[user.currentLevel] || 0) + 1 >= 10) {
        const levels = ['alphabet', 'word', 'phrase', 'sentence', 'paragraph']
        const currentIndex = levels.indexOf(user.currentLevel)
        if (currentIndex < levels.length - 1) {
          const nextLevel = levels[currentIndex + 1]
          await fetch('/api/user', {
            method: 'PUT',
            headers: { 
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ 
              userId, 
              updates: { currentLevel: nextLevel }
            }),
          })
          router.push(`/training/${nextLevel}`)
        }
      } else {
        // Fetch next exercise
        const pattern = await analyzeDyslexiaPattern(user.screeningResults)
        const exercises = await generatePersonalizedExercises(pattern, user.currentLevel)
        setCurrentExercise(exercises[0])
      }
    } catch (error) {
      console.error('An error occurred while updating progress:', error)
    }
  }

  if (!user || !currentExercise) return <div>Loading...</div>

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-100 to-blue-200">
      <Card className="w-[600px]">
        <CardHeader>
          <CardTitle className="text-3xl">{user.currentLevel.charAt(0).toUpperCase() + user.currentLevel.slice(1)} Training</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-xl">{currentExercise.text}</p>
          <div className="flex space-x-4 mb-4">
            <Button onClick={handleSpeak}>Listen</Button>
            <Button onClick={handleListen}>Speak</Button>
          </div>
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="w-full p-2 text-xl border rounded"
          />
          {feedback && <p className="mt-2 text-center text-xl">{feedback}</p>}
        </CardContent>
        <CardFooter>
          <Button onClick={handleSubmit} className="w-full">Submit</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

