import { NextResponse } from 'next/server'
import clientPromise from '@/lib/mongodb'
import { ObjectId } from 'mongodb'
import rateLimitMiddleware from '@/lib/rateLimit'
import jwtMiddleware from '@/lib/jwtMiddleware'

export async function GET(req: NextApiRequest, res: NextApiResponse) {
  await rateLimitMiddleware(req, res, async () => {
    await jwtMiddleware(req, res, async () => {
      try {
        const { searchParams } = new URL(req.url!)
        const userId = searchParams.get('userId')

        if (!userId) {
          return NextResponse.json({ error: "User ID is required" }, { status: 400 })
        }

        const client = await clientPromise
        const db = client.db("dyslexiaAssistant")

        const user = await db.collection("users").findOne({ _id: new ObjectId(userId) })
        if (!user) {
          return NextResponse.json({ error: "User not found" }, { status: 404 })
        }

        // Remove sensitive information
        const { password, ...safeUser } = user

        return NextResponse.json(safeUser)
      } catch (error) {
        console.error(error)
        return NextResponse.json({ error: "An error occurred while fetching user data" }, { status: 500 })
      }
    })
  })
}

// Similar updates for PUT method

