import './globals.css'
import { Inter, Open_Sans } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })
const openSans = Open_Sans({ subsets: ['latin'] })

export const metadata = {
  title: 'Dyslexia Reading Assistant',
  description: 'A personalized learning platform for individuals with dyslexia.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.cdnfonts.com/css/opendyslexic"
          rel="stylesheet"
        />
      </head>
      <body className={openSans.className}>{children}</body>
    </html>
  )
}

