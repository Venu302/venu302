"use client"

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { motion } from 'framer-motion'

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Fetch user data here
    // For now, we'll use a mock user
    setUser({ name: 'John Doe', level: 'Beginner', progress: 45 })
  }, [])

  const handleStartExercise = () => {
    router.push('/exercise')
  }

  if (!user) return <div>Loading...</div>

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      <h1 className="text-3xl font-bold text-primary">Welcome, {user.name}!</h1>
      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-2 text-gray-600">Current Level: {user.level}</p>
          <Progress value={user.progress} className="w-full h-2" />
          <p className="mt-2 text-sm text-gray-500">{user.progress}% complete</p>
          <Button onClick={handleStartExercise} className="mt-4">
            Start Next Exercise
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside text-gray-600">
            <li>Completed Word Recognition Exercise</li>
            <li>Achieved 80% accuracy in Sentence Structure Test</li>
            <li>Unlocked new level: Intermediate Reader</li>
          </ul>
        </CardContent>
      </Card>
    </motion.div>
  )
}

