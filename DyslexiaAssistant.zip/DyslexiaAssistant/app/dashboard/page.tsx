'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts'

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const [progressData, setProgressData] = useState<any[]>([])
  const router = useRouter()

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const userId = localStorage.getItem('userId')
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/user?userId=${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const userData = await response.json()
      if (response.ok) {
        setUser(userData)
        generateProgressData(userData.progress)
      } else {
        console.error(userData.error)
      }
    } catch (error) {
      console.error('An error occurred while fetching user data:', error)
    }
  }

  const generateProgressData = (progress: any) => {
    const data = Object.entries(progress).map(([level, score]) => ({
      level,
      score: Number(score)
    }))
    setProgressData(data)
  }

  const handleStartTraining = () => {
    router.push('/training')
  }

  if (!user) return <div>Loading...</div>

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-blue-200 p-8">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl">Welcome back, {user.name}!</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="progress">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="progress">Your Progress</TabsTrigger>
              <TabsTrigger value="stats">Statistics</TabsTrigger>
            </TabsList>
            <TabsContent value="progress">
              <div className="space-y-4">
                {Object.entries(user.progress || {}).map(([level, score]: [string, any]) => (
                  <div key={level}>
                    <div className="flex justify-between mb-1">
                      <span className="text-lg capitalize">{level}</span>
                      <span className="text-lg font-semibold">{score}/10</span>
                    </div>
                    <Progress value={score * 10} className="w-full" />
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="stats">
              <div className="w-full h-64">
                <LineChart width={600} height={300} data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="level" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="score" stroke="#8884d8" />
                </LineChart>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter>
          <Button onClick={handleStartTraining} className="w-full">Continue Training</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

