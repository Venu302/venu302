"use client"

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Fetch user data here
    // For now, we'll use a mock user
    setUser({ name: 'John Doe', level: 'Beginner' })
  }, [])

  const handleStartExercise = () => {
    router.push('/exercise')
  }

  if (!user) return <div>Loading...</div>

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto"
    >
      <h1 className="text-3xl font-bold mb-6 text-purple-800">Welcome, {user.name}!</h1>
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Your Progress</h2>
        <p className="mb-4 text-gray-600">Current Level: {user.level}</p>
        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mb-4">
          <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
        </div>
        <Button onClick={handleStartExercise} className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
          Start Next Exercise
        </Button>
      </div>
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Recent Activities</h2>
        <ul className="list-disc list-inside text-gray-600">
          <li>Completed Word Recognition Exercise</li>
          <li>Achieved 80% accuracy in Sentence Structure Test</li>
          <li>Unlocked new level: Intermediate Reader</li>
        </ul>
      </div>
    </motion.div>
  )
}

