export function Footer() {
  return (
    <footer className="bg-white shadow-md mt-8">
      <div className="container mx-auto px-6 py-4">
        <p className="text-center text-gray-600">
          © 2023 Dyslexia Reading Assistant. All rights reserved.
        </p>
      </div>
    </footer>
  )
}

